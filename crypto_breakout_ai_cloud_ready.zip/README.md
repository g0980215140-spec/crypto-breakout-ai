# Crypto Breakout AI MVP
Windows 本機版 OKX USDT 現貨掃描器。只讀取公開行情，不需要 API Key，也不會下單。

## 啟動方式
1. 安裝 Python 3.13（你已完成）。
2. 解壓縮此專案。
3. 在檔案總管開啟解壓縮資料夾，點地址列輸入 `cmd`，按 Enter。
4. 依序執行以下指令（每行輸入後按 Enter）：

   `py -m venv .venv`

   `.venv\\Scripts\\activate`

   `py -m pip install -r requirements.txt`

   `py -m uvicorn app.main:app --reload`

5. 瀏覽器開啟 http://127.0.0.1:8000
6. 按「立即掃描」。關閉命令視窗會停止網站，按 Ctrl+C 可停止服務。

## 訊號邏輯
- 突破確認：1H 收盤價高於前 20 根 K 線高點、成交量比至少 1.5、收盤價高於 EMA20。
- 接近突破：距離前高 2% 內、成交量比至少 1.2、EMA20 高於 EMA50。
- EMA 金叉：EMA20 在最新已收盤 K 線上穿 EMA50。
- 多頭觀察：EMA20 高於 EMA50 且成交量比至少 1.2。

這是 MVP 研究工具，不構成投資建議，訊號可能錯誤或失效，不能保證獲利。掃描僅在本機服務運行時執行；目前尚未加入 Telegram 通知、回測或自動交易。
