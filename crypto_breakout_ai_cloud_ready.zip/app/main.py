from fastapi import FastAPI, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from datetime import datetime, timezone
import httpx, asyncio

ROOT=Path(__file__).resolve().parent
app=FastAPI(title="Crypto Breakout AI")
app.mount("/static",StaticFiles(directory=ROOT/"static"),name="static")
OKX="https://www.okx.com"

@app.get("/")
async def home():
    return FileResponse(ROOT/"static"/"index.html")

async def get_data(client,path,params=None):
    r=await client.get(OKX+path,params=params,timeout=18)
    r.raise_for_status()
    j=r.json()
    if j.get("code")!="0": raise RuntimeError(j.get("msg","OKX API error"))
    return j.get("data",[])

def ema(values,n):
    a=2/(n+1); out=[values[0]]
    for x in values[1:]: out.append(a*x+(1-a)*out[-1])
    return out

async def scan_one(client,inst):
    rows=await get_data(client,"/api/v5/market/candles",{"instId":inst,"bar":"1H","limit":"100"})
    rows=list(reversed(rows))
    closed=[r for r in rows if len(r)>8 and r[8]=="1"]
    if len(closed)<55: closed=rows[:-1]
    if len(closed)<55:return None
    c=[float(r[4]) for r in closed]; h=[float(r[2]) for r in closed]; v=[float(r[5]) for r in closed]
    e20,e50=ema(c,20),ema(c,50); close=c[-1]; high=max(h[-21:-1]); avg=sum(v[-21:-1])/20
    vr=v[-1]/avg if avg else 0
    near=(high-close)/high*100 if high else 999
    cross=e20[-2]<=e50[-2] and e20[-1]>e50[-1]
    bullish=e20[-1]>e50[-1]
    if close>high and vr>=1.5 and close>e20[-1]: signal,score="突破確認",90
    elif 0<=near<=2 and vr>=1.2 and close>e20[-1] and bullish: signal,score="接近突破",70
    elif cross: signal,score="EMA金叉",65
    elif bullish and vr>=1.2: signal,score="多頭觀察",50
    else: signal,score="觀察中",20
    return {"instId":inst,"price":close,"ema20":e20[-1],"ema50":e50[-1],"prevHigh":high,"volRatio":vr,"nearPct":near,"signal":signal,"score":score,"crossed":cross,"bullish":bullish}

@app.get("/api/scan")
async def scan(limit:int=Query(50,ge=10,le=100)):
    try:
        async with httpx.AsyncClient() as client:
            tickers=await get_data(client,"/api/v5/market/tickers",{"instType":"SPOT"})
            pairs=[x for x in tickers if x.get("instId","").endswith("-USDT")]
            pairs.sort(key=lambda x:float(x.get("volCcyQuote") or 0),reverse=True)
            chosen=[x["instId"] for x in pairs[:limit]]
            sem=asyncio.Semaphore(8)
            async def safe(inst):
                async with sem:
                    try:return await scan_one(client,inst)
                    except Exception as e:return {"instId":inst,"error":str(e)}
            raw=await asyncio.gather(*(safe(x) for x in chosen))
            good=[x for x in raw if x and "error" not in x]
            order={"突破確認":0,"接近突破":1,"EMA金叉":2,"多頭觀察":3,"觀察中":4}
            good.sort(key=lambda x:(order.get(x["signal"],9),-x["score"],-x["volRatio"]))
            return {"ok":True,"updatedAt":datetime.now(timezone.utc).isoformat(),"scanned":len(chosen),"count":len(good),"signals":good,"errors":[x for x in raw if x and "error" in x][:8]}
    except Exception as e:return {"ok":False,"error":str(e),"signals":[]}

@app.get("/api/health")
async def health():return {"ok":True}
